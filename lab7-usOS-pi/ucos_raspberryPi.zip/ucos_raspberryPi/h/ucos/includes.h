#include    "ucos/os_cpu.h"
#include    "ucos/os_cfg.h"
#include    "ucos/ucos_ii.h"

extern void *memcpy(void *destination,const void *source,unsigned int size);

extern void *memset(void * m,int c,unsigned int size);
