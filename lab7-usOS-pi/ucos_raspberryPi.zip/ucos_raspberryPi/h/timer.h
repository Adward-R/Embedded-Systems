
#ifndef TIMER_H_
#define TIMER_H_

void timer_init( void );

#endif /* TIMER_H_ */
